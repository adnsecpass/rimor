function addInput(form, name, value) {
    const input = document.createElement("input");
    input.name = name;
    input.value = value;
    form.appendChild(input);
}

/**
 * Checks whether WebAuthn is supported by the browser or not.
 * @return true if supported, false if it is not supported or not in secure context
 */
function isWebAuthnSupportedByTheBrowser() {
  if (window.isSecureContext) {
    // This feature is available only in secure contexts in some or all supporting browsers.
    if ('credentials' in navigator) {
      return true;
    }
    console.warn('Oh no! This browser does not support WebAuthn.');
    return false;
  }
  console.warn('WebAuthn feature is available only in secure contexts. For testing over HTTP, you can use the origin "localhost".');
  return false;
}

/**
 * Trigger on cancel pattern of the FIDO2 authentication step.
 * 
 * Provides an alternative when the user decides to 
 * cancel the fido2 credential operation(create or fetch) or
 * the operation fails and the error cannot be handled.
 */
function cancelFido2() {
  // we have to do a top-level request instead of AJAX
  const form = document.createElement("form");
  form.method = "POST";
  form.style.display = "none";
  addInput(form, "cancel_fido2", "true");
  document.body.appendChild(form);
  form.submit();
}
